#include "igraph.h"
#include <algorithm>

void IGraph::Copy(const IGraph *from, IGraph *to) {
    if (from == nullptr || to == nullptr) {
        return;
    }
    int lists_amount = from->VerticesCount();

    for (int i = 0; i < lists_amount; i++) {
        std::vector<int> one_list = from->GetNextVertices(i);
        int size_list = static_cast<int>(one_list.size());
        for (int j = 0; j < size_list; j++) {
            to->AddEdge(i, one_list[static_cast<size_t>(j)]);
        }
    }
}

bool IGraph::IsIndexCorrect(int index) const {
    return (index >= 0) && (index < VerticesCount());
}

bool IGraph::IsGraphCorrect() const {
    return VerticesCount() > 0;
}
